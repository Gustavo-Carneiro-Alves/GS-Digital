package br.com.fiap.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Setup {
	
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String name = "Nome";
	private LocalDate dt_nasc = LocalDate.of(2000, 02, 01);
	private String CPF = "111.222.333-04";
	private String RG = "555666777";
	private String dg_RG = "08";
	private LocalDate dt_cad = LocalDate.now();
	
	public Long getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDate getDt_nasc() {
		return dt_nasc;
	}
	public void setDt_nasc(LocalDate dt_nasc) {
		this.dt_nasc = dt_nasc;
	}
	public String getCPF() {
		return CPF;
	}
	public void setCPF(String cPF) {
		CPF = cPF;
	}
	public String getRG() {
		return RG;
	}
	public void setRG(String rG) {
		RG = rG;
	}
	public String getDg_RG() {
		return dg_RG;
	}
	public void setDg_RG(String dg_RG) {
		this.dg_RG = dg_RG;
	}
	public LocalDate getDt_cad() {
		return dt_cad;
	}
	public void setDt_cad(LocalDate dt_cad) {
		this.dt_cad = dt_cad;
	}

	public void setId(Long id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Setup [id=" + id + ", name=" + name + ", dt_nasc=" + dt_nasc + ", CPF=" + CPF + ", RG=" + RG
				+ ", dg_RG=" + dg_RG + ", dt_cad=" + dt_cad + ", imagePath=" + "]";
	}
	
	

}
